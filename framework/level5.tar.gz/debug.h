#ifndef DEBUG_H
#define DEBUG_H

#include "engine/Bug.h"

Bug & getDebugger();

#endif
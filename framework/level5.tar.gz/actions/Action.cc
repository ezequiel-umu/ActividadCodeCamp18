#include "Action.h"

Action::Action(const Location &worker) : worker(worker)
{
  
}

Action::~Action() {
    
}
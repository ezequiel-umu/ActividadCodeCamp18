#include "Action.h"

Action::Action(Ant &worker) : worker(worker)
{
  
}

Action::~Action() {
    
}
// Comentar las líneas sobre las partes que NO
// se quieran usar. 
// Desactivar un algoritmo podría hacer no funcionar partes
// del framework de inteligencia artificial
#define DEBUG 1
#define CALCULATE_DANGER 1
#define CALCULATE_LINEAR_INFLUENCE 1
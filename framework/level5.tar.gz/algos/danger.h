#ifndef DANGER_H
#define DANGER_H

#include "../engine/State.h"

void calculateDanger();

#endif